

-- Dirt Monster by Zeg9

mobs:register_mob("mobs:dirt_monster", {
	type = "monster",
	passive = false,
	damage = 3,
	attack_type = "dogfight",
	shoot_interval = .5,
--	arrow = "default:sword_diamond",
	shoot_offset = 2,
	hp_min = 10,
	hp_max = 25,
	armor = 80,
	collisionbox = {-0.5, -1.5, -0.5, 0.5, 0.5, 0.5},
	visual = "mesh",
	mesh = "mobs_stone_monster.x",
	textures = {
		{"mobs_dirt_monster.png"},
	},
	visual_size = {x=1, y=1},
	blood_texture = "green_slime_top.png",
	makes_footstep_sound = false,
	sounds = {
		random = "mobs_dirtmonster",
	},
	view_range = 10,
	walk_velocity = 0.5,
	run_velocity = 2,
	jump = true,
	jump_height = 1.5,
	fall_damage = 0,
	fall_speed = -6,
	drops = {
		{name = "default:dirt",
		chance = 9, min = 1, max = 3,},
		{name = "default:sword_diamond",
		chance = 1, min = 1, max = 9,},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	animation = {
		speed_normal = 15,		speed_run = 15,
		stand_start = 0,		stand_end = 14,
		walk_start = 15,		walk_end = 38,
		run_start = 40,			run_end = 63,
		punch_start = 15,		punch_end = 38, -- was 40 & 63
	},
})

mobs:register_spawn("mobs:dirt_monster", {"default:dirt"}, 5, 0, 5000, 1, -20)

mobs:register_egg("mobs:dirt_monster", "Spawn Zombie", "default_grass_side.png", 1)

