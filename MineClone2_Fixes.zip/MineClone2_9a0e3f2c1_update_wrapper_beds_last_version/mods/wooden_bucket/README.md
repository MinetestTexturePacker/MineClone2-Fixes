# wooden_bucket

Adds wooden buckets. These are easy to make, but can't be used to carry lava.


The source is available on github.

Code: LGPL2, Textures: CC-BY-SA 3.0

Mod dependencies: default, bucket

Download: https://github.com/duane-r/wooden_bucket/archive/master.zip
