-- Wielded Item Transformations - http://dev.minetest.net/texture

wieldview.transform = {
	["default:torch"]="R270",
	["default:sapling"]="R270",
	["flowers:dandelion_white"]="R270",
	["flowers:dandelion_yellow"]="R270",
	["flowers:geranium"]="R270",
	["flowers:rose"]="R270",
	["flowers:tulip"]="R270",
	["flowers:viola"]="R270",
	["bucket:bucket_empty"]="R270",
	["bucket:bucket_water"]="R270",
	["bucket:bucket_lava"]="R270",
	["screwdriver:screwdriver"]="R270",
	["screwdriver:screwdriver1"]="R270",
	["screwdriver:screwdriver2"]="R270",
	["screwdriver:screwdriver3"]="R270",
	["screwdriver:screwdriver4"]="R270",
	["vessels:glass_bottle"]="R270",
	["vessels:drinking_glass"]="R270",
	["vessels:steel_bottle"]="R270",
}

