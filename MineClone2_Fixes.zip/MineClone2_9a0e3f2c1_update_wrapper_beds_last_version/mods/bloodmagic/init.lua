on_rightclick = function(itemstack, user, pointed_thing)

		local damage = 2

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)

	end,



-- Items

minetest.register_node("bloodmagic:altar", {
	description = "Blood Altar",
	tiles = {"altar_top.png", "altar_top.png", "altar_side.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),
 on_construct = function(pos) 
      local spawnerID = minetest.add_particlespawner({
         amount = 1,
         time = 0,
         minpos = {x = pos.x - 0.1, y = pos.y + 0.1, z = pos.z  },
         maxpos = {x = pos.x + 0.1, y = pos.y + 0.2, z = pos.z + 1 },
         minvel = {x = 0.1, y = 0.1, z = 0.1},
         maxvel = {x = 1, y = 1, z = 1},
         minacc = {x = -0.15, y = -0.02, z = -0.15},
         maxacc = {x = 0.15, y = -0.01, z = 0.15},
         minexptime = 4,
         maxexptime = 6,
         minsize = 0.1,
         maxsize = 1,
		vertical = true,
         collisiondetection = false,
         texture = "blood_droplet.png"
      })
      local meta = minetest.get_meta(pos)
      meta:set_int("fire_particle_spawner_id", spawnerID)
   end,
   
   on_destruct = function(pos)
      local meta = minetest.get_meta(pos)
      local spawnerID = meta:get_int("fire_particle_spawner_id")
      
      minetest.delete_particlespawner(spawnerID)
   end,

})

minetest.register_node("bloodmagic:lily", {
	description = "Blood Lily",
	drawtype = "plantlike",
	tiles = {"blood_lily.png"},
	inventory_image = "blood_lily.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-3 / 16, -7 / 16, -3 / 16, 3 / 16, 4 / 16, 3 / 16}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2,
		leafdecay = 3, leafdecay_drop = 1, flower = 1},
	on_use = minetest.item_eat(50),
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = function(pos, placer, itemstack)
		if placer:is_player() then
			minetest.set_node(pos, {name = "bloodmagic:lily", param2 = 1})
		end
	end,
})



minetest.register_node("bloodmagic:knife", {
	description = "Sacrificial Knife",
	drawtype = "plantlike",
	tiles = {"sacrifice_knife2.png"},
	inventory_image = "sacrifice_knife.png",
	wield_image = "sacrifice_knife.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	stack_max = 1,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-3 / 16, -7 / 16, -3 / 16, 3 / 16, 4 / 16, 3 / 16}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2,
		leafdecay = 3, leafdecay_drop = 1},
	sounds = default.node_sound_leaves_defaults(),
	
	
	on_place = function(itemstack, user, pointed_thing)
		local yermister = minetest.get_node(pointed_thing.under)
		if yermister.name == "bloodmagic:altar" then
			local yetripolgio = math.random(1,15)
			if yetripolgio < 6 then
				minetest.chat_send_player(user:get_player_name(), "The gods are pleased with you")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:bloodsword")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:bloodaxe")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:bloodpick")
				local damage = 4

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)

			
			elseif yetripolgio == 8 then
				minetest.chat_send_player(user:get_player_name(), "The gods are angered by you")
				user:set_hp(0)

			else
				minetest.chat_send_player(user:get_player_name(), "The gods laugh hysterically at your attempt at a ritual")
				local damage = 2

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)


			end
		elseif yermister.name == "bones:bones" then
			yetripolgio = math.random(1,2)
			if yetripolgio == 1 then
				minetest.chat_send_player(user:get_player_name(), "The gods accept your offering")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:dried_blood 5")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:lily")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:knife")
				minetest.remove_node({x = pointed_thing.under.x, y = pointed_thing.under.y, z = pointed_thing.under.z})
				local damage = 2

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)


			else
				minetest.chat_send_player(user:get_player_name(), "The gods frown upon your offering")
				minetest.remove_node({x = pointed_thing.under.x, y = pointed_thing.under.y, z = pointed_thing.under.z})
				local damage = 2

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)


			end
		elseif yermister.name == "bloodmagic:altar2" then
			yetripolgio = math.random(1,20)
			if yetripolgio == 10 then
				minetest.chat_send_all("The gods are pleased with your mighty offering")
				minetest.add_item({x = pointed_thing.under.x, y = pointed_thing.under.y + 3, z = pointed_thing.under.z}, "bloodmagic:godsword")
				minetest.chat_send_player(user:get_player_name(), "You have completed the path of the blood mage. good bye and good luck")
			local damage = 6

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)



			else
				minetest.chat_send_player(user:get_player_name(), "The gods laugh hysterically at your attempt at a ritual")
				local damage = 6

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)


			end

		else
		minetest.chat_send_player(user:get_player_name(), yermister.name.." Isn't an altar, silly!")
		local damage = 1

		local gethp = user:get_hp()
		user:set_hp(gethp-damage)

		
		end
		
	end,
})


minetest.register_node("bloodmagic:crystal", {
	description = "Petrified Blood",
	tiles = {"default_stone.png^blood_ore.png"},
	groups = {cracky = 1},
	drop = "bloodmagic:dried_blood",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_ore({
		ore_type       = "scatter",
		ore            = "bloodmagic:crystal",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = 1025,
		y_max          = 31000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "bloodmagic:crystal",
		wherein        = "default:stone",
		clust_scarcity = 18 * 18 * 18,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -255,
		y_max          = -64,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "bloodmagic:crystal",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -256,
	})


minetest.register_craftitem("bloodmagic:dried_blood", {
	description = "Dried Blood",
	inventory_image = "blood_d.png",
})

minetest.register_craftitem("bloodmagic:rune", {
	description = "Blood Rune",
	inventory_image = "blood_rune.png",
})


minetest.register_node("bloodmagic:bloodblock", {
	description = "Compacted blood",
	tiles = {"blood_block.png"},
	is_ground_content = false,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_decoration({
			deco_type = "simple",
			place_on = {"default:dirt_with_grass"},
			sidelen = 16,
			noise_params = {
				offset = 0,
				scale = 0.007,
				spread = {x = 100, y = 100, z = 100},
				seed = 329,
				octaves = 3,
				persist = 0.6
			},
			y_min = 40,
			y_max = 100,
			decoration = "bloodmagic:lily",
		})


minetest.register_ore({
		ore_type        = "blob",
		ore             = "bloodmagic:bloodblock",
		wherein         = {"default:stone"},
		clust_scarcity  = 16 * 16 * 16,
		clust_size      = 5,
		y_min           = -31000,
		y_max           = -20000,
		noise_threshold = 0.0,
		noise_params    = {
			offset = 0.5,
			scale = 0.2,
			spread = {x = 5, y = 5, z = 5},
			seed = 766,
			octaves = 1,
			persist = 0.0
		},
	})



-- Crafting

minetest.register_craft({
	output = 'bloodmagic:altar',
	recipe = {
		{'bloodmagic:lily', 'bloodmagic:rune', 'bloodmagic:lily'},
		{'bloodmagic:dried_blood', 'bloodmagic:bloodblock', 'bloodmagic:dried_blood'},
		{'bloodmagic:bloodblock', 'bloodmagic:bloodblock', 'bloodmagic:bloodblock'},
	}
})

minetest.register_craft({
	output = 'bloodmagic:bloodblock',
	recipe = {
		{'bloodmagic:dried_blood', 'bloodmagic:dried_blood', 'bloodmagic:dried_blood'},
		{'bloodmagic:dried_blood', 'bloodmagic:dried_blood', 'bloodmagic:dried_blood'},
		{'bloodmagic:dried_blood', 'bloodmagic:dried_blood', 'bloodmagic:dried_blood'},
	}
})

minetest.register_craft({
	output = 'bloodmagic:knife',
	recipe = {
		{'', 'bloodmagic:dried_blood', ''},
		{'', 'bloodmagic:dried_blood', ''},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'bloodmagic:rune',
	recipe = {
		{'default:stone', 'default:stone', 'default:stone'},
		{'default:stone', 'bloodmagic:dried_blood', 'default:stone'},
		{'default:stone', 'default:stone', 'default:stone'},
	}
})


-- UPDATE CONTENT BELOW

minetest.register_node("bloodmagic:blood_source", {
	description = "blood source block. too op for you",
	drawtype = "liquid",
	tiles = {
		{
			name = "blood_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 5,
			},
		},
	},
	special_tiles = {
		-- New-style water source material (mostly unused)
		{
			name = "blood_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 5,
			},
			backface_culling = false,
		},
	},
	alpha = 160,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "bloodmagic:flowing_blood",
	liquid_alternative_source = "bloodmagic:blood_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 103, r = 255, g = 0, b = 0},
	groups = {water = 3, liquid = 3, puts_out_fire = 1, cools_lava = 1},
--	sounds = default.node_sound_water_defaults(),
})



minetest.register_node("bloodmagic:flowing_blood", {
	description = "Flowing Blood",
	drawtype = "flowingliquid",
	tiles = {"blood.png"},
	special_tiles = {
		{
			name = "blood_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 5,
			},
		},
		{
			name = "blood_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 5,
			},
		},
	},
	alpha = 160,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "bloodmagic:flowing_blood",
	liquid_alternative_source = "bloodmagic:blood_source",
	liquid_viscosity = 1,
	post_effect_color = {a = 103, r = 255, g = 0, b = 0},
	groups = {water = 3, liquid = 3, puts_out_fire = 1,
		not_in_creative_inventory = 1, cools_lava = 1},
--	sounds = default.node_sound_water_defaults(),
})


minetest.register_node("bloodmagic:runestone", {
	description = "Runestone",
	tiles = {"runestone.png"},
	groups = {cracky = 3, stone = 1},
	drop = 'default:cobble',
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("bloodmagic:runestone2", {
	description = "Runestone",
	tiles = {"runestone2.png"},
	groups = {cracky = 3, stone = 1},
	drop = 'default:cobble',
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'bloodmagic:runestone',
	recipe = {
		{'default:stone', 'default:stone', 'default:stone'},
		{'default:stone', 'bloodmagic:rune', 'default:stone'},
		{'default:stone', 'default:stone', 'default:stone'},
	}
})

minetest.register_craft({
	output = 'bloodmagic:runestone2',
	recipe = {
		{'bloodmagic:dried_blood', 'default:stone', 'bloodmagic:dried_blood'},
		{'default:stone', 'bloodmagic:dried_blood', 'default:stone'},
		{'bloodmagic:dried_blood', 'default:stone', 'bloodmagic:dried_blood'},
	}
})


minetest.register_node("bloodmagic:headstone", {
	description = "Bloody Relic",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1.69,
	tiles = {"headstone.png"},
	inventory_image = "headstone.png",
	wield_image = "headstone.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	groups = {snappy = 3, flora = 1, attached_node = 1, flammable = 1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-7 / 16, -0.5, -7 / 16, 7 / 16, 1.19, 7 / 16},
	},
})


minetest.register_tool("bloodmagic:bloodpick", {
	description = "Bloody Pickaxe",
	inventory_image = "bloodpick.png",
	tool_capabilities = {
		full_punch_interval = 0.01,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.5, [2]=0.5, [3]=0.5}, uses=90, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
	sound = {breaks = "default_tool_breaks"},
})


minetest.register_tool("bloodmagic:bloodaxe", {
	description = "Bloody Axe",
	inventory_image = "bloodaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.50, [2]=0.40, [3]=0.30}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
})



minetest.register_tool("bloodmagic:bloodsword", {
	description = "bloody Sword",
	inventory_image = "bloodsword.png",
	tool_capabilities = {
		full_punch_interval = 0.09,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.001, [2]=0.001, [3]=0.001}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=17},
	},
	sound = {breaks = "default_tool_breaks"},
})



--BUCKET
bucket.register_liquid(
	"bloodmagic:blood_source",
	"bloodmagic:flowing_blood",
	"bloodmagic:bucket_blood",
	"bucket_blood.png",
	"Bucket of blood"
)

mobs:register_mob("bloodmagic:demon", {
   type = "monster",
   rotate = 180,
   hp_min = 1000,
   hp_max = 1250,
   collisionbox = {-0.8, -2.1, -0.8, 0.8, 2.6, 0.8},
   visual_size = {x=2, y=2},
   visual = "mesh",
   mesh = "mobs_balrog.b3d",
	textures = {
		{"mobs_balrog_balrog.png"},
	},
   makes_footstep_sound = true,
   view_range = 15,
   armor = 100,
   walk_velocity = 1,
   run_velocity = 3,
   damage = 30,
   drops = {
      {name = "bloodmagic:altar2",
      chance = 11,
      min = 1,
      max = 2}
   },
   drawtype = "front",
   water_damage = 0,
   lava_damage = 0,
   light_damage = 0,
   on_rightclick = nil,
   attack_type = "dogfight",
   animation = {
      stand_start = 0,
      stand_end = 240,
      walk_start = 240,
      walk_end = 300,
      punch_start = 300,
      punch_end = 380,
      speed_normal = 15,
      speed_run = 15,
   },
   jump = true,
   sounds = {
      war_cry = "mobs_howl",
      death = "mobs_howl",
      attack = "mobs_stone_death",
   },

   --
   -- This is from Lava Flan by Zeg9
   -- lava_flan.lua, mobs_monster, mobs_redo
   --

   on_die = function(self, pos)
      minetest.set_node(pos, {name = "fire:basic_flame"})
      self.object:remove()

      minetest.add_particlespawner({
         amount = 20,
         time = 0.25,
         minpos = pos,
         maxpos = pos,
         minvel = {x = -2, y = -2, z = -2},
         maxvel = {x = 2, y = 2, z = 2},
         minacc = {x = 0, y = -10, z = 0},
         maxacc = {x = 0, y = -10, z = 0},
         minexptime = 0.1,
         maxexptime = 1,
         minsize = 0.5,
         maxsize = 1.0,
         texture = "fire_basic_flame.png",
      })
   end,
})

minetest.register_tool("bloodmagic:godsword", {
	description = "Godly BloodSword",
	inventory_image = "bloodsword.png",
	tool_capabilities = {
		full_punch_interval = 0.00000000000001,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.0001, [2]=0.0001, [3]=0.0001}, uses=99999999999999999, maxlevel=3},
		},
		damage_groups = {fleshy=120},
	},
	sound = {breaks = "default_tool_breaks"},
})


minetest.register_node("bloodmagic:altar2", {
	description = "Godly Blood Altar",
	tiles = {"altar_top.png", "altar_top.png", "altar_2.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),

 on_construct = function(pos) 
      local spawnerID = minetest.add_particlespawner({
         amount = 3,
         time = 0,
         minpos = {x = pos.x - 0.1, y = pos.y + 0.1, z = pos.z  },
         maxpos = {x = pos.x + 0.1, y = pos.y + 0.2, z = pos.z + 1 },
         minvel = {x = 0.1, y = 0.1, z = 0.1},
         maxvel = {x = 1, y = 1, z = 1},
         minacc = {x = -0.15, y = -0.02, z = -0.15},
         maxacc = {x = 0.15, y = -0.01, z = 0.15},
         minexptime = 4,
         maxexptime = 6,
         minsize = 0.1,
         maxsize = 1,
		vertical = true,
         collisiondetection = false,
         texture = "blood_droplet.png"
      })
      local meta = minetest.get_meta(pos)
      meta:set_int("fire_particle_spawner_id", spawnerID)
   end,
   
   on_destruct = function(pos)
      local meta = minetest.get_meta(pos)
      local spawnerID = meta:get_int("fire_particle_spawner_id")
      
      minetest.delete_particlespawner(spawnerID)
   end,

})



